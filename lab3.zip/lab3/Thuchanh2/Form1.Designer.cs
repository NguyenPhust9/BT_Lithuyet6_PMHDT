﻿namespace Thuchanh2
{
    partial class Form1
    {
        private System.ComponentModel.IContainer components = null;

        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.txtDiaChi = new System.Windows.Forms.TextBox();
            this.dtpNgaySinh = new System.Windows.Forms.DateTimePicker();
            this.txtLop = new System.Windows.Forms.TextBox();
            this.txtHoTen = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.btnThoat = new System.Windows.Forms.Button();
            this.btnXoa = new System.Windows.Forms.Button();
            this.btnSua = new System.Windows.Forms.Button();
            this.btnThem = new System.Windows.Forms.Button();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.lvSinhVien = new System.Windows.Forms.ListView();
            this.colHoTen = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.colNgaySinh = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.colLop = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.colDiaChi = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.groupBox1.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.groupBox3.SuspendLayout();
            this.SuspendLayout();

            // 
            // label1 - tiêu đề
            // 
            this.label1.Font = new System.Drawing.Font("Segoe UI", 20F, System.Drawing.FontStyle.Bold);
            this.label1.ForeColor = System.Drawing.Color.RoyalBlue;
            this.label1.Location = new System.Drawing.Point(100, 15);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(600, 45);
            this.label1.Text = "DANH MỤC SINH VIÊN";
            this.label1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;

            // 
            // groupBox1 - Thông tin sinh viên
            // 
            this.groupBox1.Controls.Add(this.txtDiaChi);
            this.groupBox1.Controls.Add(this.dtpNgaySinh);
            this.groupBox1.Controls.Add(this.txtLop);
            this.groupBox1.Controls.Add(this.txtHoTen);
            this.groupBox1.Controls.Add(this.label5);
            this.groupBox1.Controls.Add(this.label4);
            this.groupBox1.Controls.Add(this.label3);
            this.groupBox1.Controls.Add(this.label2);
            this.groupBox1.Font = new System.Drawing.Font("Segoe UI", 10F);
            this.groupBox1.Location = new System.Drawing.Point(40, 70);
            this.groupBox1.Size = new System.Drawing.Size(720, 120);
            this.groupBox1.Text = "Thông tin sinh viên";

            // 
            // txtHoTen
            // 
            this.txtHoTen.Font = new System.Drawing.Font("Segoe UI", 10F);
            this.txtHoTen.Location = new System.Drawing.Point(90, 30);
            this.txtHoTen.Size = new System.Drawing.Size(240, 25);

            // 
            // txtLop
            // 
            this.txtLop.Font = new System.Drawing.Font("Segoe UI", 10F);
            this.txtLop.Location = new System.Drawing.Point(440, 30);
            this.txtLop.Size = new System.Drawing.Size(240, 25);

            // 
            // dtpNgaySinh
            // 
            this.dtpNgaySinh.Font = new System.Drawing.Font("Segoe UI", 10F);
            this.dtpNgaySinh.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.dtpNgaySinh.Location = new System.Drawing.Point(90, 70);
            this.dtpNgaySinh.Size = new System.Drawing.Size(240, 25);

            // 
            // txtDiaChi
            // 
            this.txtDiaChi.Font = new System.Drawing.Font("Segoe UI", 10F);
            this.txtDiaChi.Location = new System.Drawing.Point(440, 70);
            this.txtDiaChi.Size = new System.Drawing.Size(240, 25);

            // 
            // label2 - label5
            // 
            this.label2.Text = "Họ tên:";
            this.label2.Location = new System.Drawing.Point(25, 33);
            this.label2.AutoSize = true;

            this.label3.Text = "Lớp:";
            this.label3.Location = new System.Drawing.Point(390, 33);
            this.label3.AutoSize = true;

            this.label4.Text = "Ngày sinh:";
            this.label4.Location = new System.Drawing.Point(15, 74);
            this.label4.AutoSize = true;

            this.label5.Text = "Địa chỉ:";
            this.label5.Location = new System.Drawing.Point(390, 74);
            this.label5.AutoSize = true;

            // 
            // groupBox2 - Chức năng
            // 
            this.groupBox2.Controls.Add(this.btnThoat);
            this.groupBox2.Controls.Add(this.btnXoa);
            this.groupBox2.Controls.Add(this.btnSua);
            this.groupBox2.Controls.Add(this.btnThem);
            this.groupBox2.Font = new System.Drawing.Font("Segoe UI", 10F);
            this.groupBox2.Location = new System.Drawing.Point(40, 200);
            this.groupBox2.Size = new System.Drawing.Size(720, 70);
            this.groupBox2.Text = "Chức năng";

            // 
            // Buttons
            // 
            var btnFont = new System.Drawing.Font("Segoe UI", 10F, System.Drawing.FontStyle.Bold);

            this.btnThem.Font = btnFont;
            this.btnThem.Text = "Thêm";
            this.btnThem.Size = new System.Drawing.Size(120, 35);
            this.btnThem.Location = new System.Drawing.Point(60, 25);
            this.btnThem.Click += new System.EventHandler(this.btnThem_Click);

            this.btnSua.Font = btnFont;
            this.btnSua.Text = "Sửa";
            this.btnSua.Size = new System.Drawing.Size(120, 35);
            this.btnSua.Location = new System.Drawing.Point(220, 25);
            this.btnSua.Click += new System.EventHandler(this.btnSua_Click);

            this.btnXoa.Font = btnFont;
            this.btnXoa.Text = "Xóa";
            this.btnXoa.Size = new System.Drawing.Size(120, 35);
            this.btnXoa.Location = new System.Drawing.Point(380, 25);
            this.btnXoa.Click += new System.EventHandler(this.btnXoa_Click);

            this.btnThoat.Font = btnFont;
            this.btnThoat.Text = "Thoát";
            this.btnThoat.Size = new System.Drawing.Size(120, 35);
            this.btnThoat.Location = new System.Drawing.Point(540, 25);
            this.btnThoat.Click += new System.EventHandler(this.btnThoat_Click);

            // 
            // groupBox3 - Thông tin chung
            // 
            this.groupBox3.Controls.Add(this.lvSinhVien);
            this.groupBox3.Font = new System.Drawing.Font("Segoe UI", 10F);
            this.groupBox3.Location = new System.Drawing.Point(40, 280);
            this.groupBox3.Size = new System.Drawing.Size(720, 250);
            this.groupBox3.Text = "Thông tin chung sinh viên";

            // 
            // lvSinhVien
            // 
            this.lvSinhVien.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            this.colHoTen,
            this.colNgaySinh,
            this.colLop,
            this.colDiaChi});
            this.lvSinhVien.Font = new System.Drawing.Font("Segoe UI", 10F);
            this.lvSinhVien.FullRowSelect = true;
            this.lvSinhVien.GridLines = true;
            this.lvSinhVien.View = System.Windows.Forms.View.Details;
            this.lvSinhVien.Location = new System.Drawing.Point(15, 30);
            this.lvSinhVien.Size = new System.Drawing.Size(690, 200);
            this.lvSinhVien.SelectedIndexChanged += new System.EventHandler(this.lvSinhVien_SelectedIndexChanged);

            this.colHoTen.Text = "Họ tên";
            this.colHoTen.Width = 180;

            this.colNgaySinh.Text = "Ngày sinh";
            this.colNgaySinh.Width = 150;

            this.colLop.Text = "Lớp";
            this.colLop.Width = 150;

            this.colDiaChi.Text = "Địa chỉ";
            this.colDiaChi.Width = 200;

            // 
            // Form1
            // 
            this.ClientSize = new System.Drawing.Size(800, 560);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.groupBox3);
            this.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.Text = "Danh sách sinh viên";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.groupBox2.ResumeLayout(false);
            this.groupBox3.ResumeLayout(false);
            this.ResumeLayout(false);
        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.TextBox txtDiaChi;
        private System.Windows.Forms.DateTimePicker dtpNgaySinh;
        private System.Windows.Forms.TextBox txtLop;
        private System.Windows.Forms.TextBox txtHoTen;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.Button btnThoat;
        private System.Windows.Forms.Button btnXoa;
        private System.Windows.Forms.Button btnSua;
        private System.Windows.Forms.Button btnThem;
        private System.Windows.Forms.GroupBox groupBox3;
        private System.Windows.Forms.ListView lvSinhVien;
        private System.Windows.Forms.ColumnHeader colHoTen;
        private System.Windows.Forms.ColumnHeader colNgaySinh;
        private System.Windows.Forms.ColumnHeader colLop;
        private System.Windows.Forms.ColumnHeader colDiaChi;
    }
}
