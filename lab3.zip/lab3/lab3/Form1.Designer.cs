﻿namespace lab3
{
    partial class Form1
    {
        private System.ComponentModel.IContainer components = null;

        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
                components.Dispose();
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        private void InitializeComponent()
        {
            this.pictureBoxLogo = new System.Windows.Forms.PictureBox();
            this.panelHeader = new System.Windows.Forms.Panel();
            this.labelTitle = new System.Windows.Forms.Label();
            this.labelChonBan = new System.Windows.Forms.Label();
            this.comboBoxBan = new System.Windows.Forms.ComboBox();
            this.groupBoxMonAn = new System.Windows.Forms.GroupBox();
            this.listViewOrder = new System.Windows.Forms.ListView();
            this.colTenMon = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.colSoLuong = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.btnXoa = new System.Windows.Forms.Button();
            this.btnOrder = new System.Windows.Forms.Button();

            // Các nút món ăn
            this.btnMon1 = new System.Windows.Forms.Button();
            this.btnMon2 = new System.Windows.Forms.Button();
            this.btnMon3 = new System.Windows.Forms.Button();
            this.btnMon4 = new System.Windows.Forms.Button();
            this.btnMon5 = new System.Windows.Forms.Button();
            this.btnMon6 = new System.Windows.Forms.Button();
            this.btnMon7 = new System.Windows.Forms.Button();
            this.btnMon8 = new System.Windows.Forms.Button();
            this.btnMon9 = new System.Windows.Forms.Button();
            this.btnMon10 = new System.Windows.Forms.Button();
            this.btnMon11 = new System.Windows.Forms.Button();
            this.btnMon12 = new System.Windows.Forms.Button();
            this.btnMon13 = new System.Windows.Forms.Button();
            this.btnMon14 = new System.Windows.Forms.Button();
            this.btnMon15 = new System.Windows.Forms.Button();
            this.btnMon16 = new System.Windows.Forms.Button();

            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxLogo)).BeginInit();
            this.panelHeader.SuspendLayout();
            this.groupBoxMonAn.SuspendLayout();
            this.SuspendLayout();

            // pictureBoxLogo
            this.pictureBoxLogo.Image = global::lab3.Properties.Resources.food_logo;
            this.pictureBoxLogo.Location = new System.Drawing.Point(20, 10);
            this.pictureBoxLogo.Size = new System.Drawing.Size(70, 70);
            this.pictureBoxLogo.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBoxLogo.TabStop = false;

            // labelTitle
            this.labelTitle.Font = new System.Drawing.Font("Segoe UI", 20F, System.Drawing.FontStyle.Bold);
            this.labelTitle.ForeColor = System.Drawing.Color.White;
            this.labelTitle.Location = new System.Drawing.Point(110, 25);
            this.labelTitle.Size = new System.Drawing.Size(420, 40);
            this.labelTitle.Text = "Quán ăn nhanh Hưng Thịnh";

            // panelHeader
            this.panelHeader.BackColor = System.Drawing.Color.ForestGreen;
            this.panelHeader.Controls.Add(this.pictureBoxLogo);
            this.panelHeader.Controls.Add(this.labelTitle);
            this.panelHeader.Dock = System.Windows.Forms.DockStyle.Top;
            this.panelHeader.Size = new System.Drawing.Size(600, 90);

            // labelChonBan
            this.labelChonBan.AutoSize = true;
            this.labelChonBan.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Bold);
            this.labelChonBan.Location = new System.Drawing.Point(35, 105);
            this.labelChonBan.Text = "Chọn bàn:";

            // comboBoxBan
            this.comboBoxBan.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comboBoxBan.Font = new System.Drawing.Font("Segoe UI", 11F);
            this.comboBoxBan.Location = new System.Drawing.Point(130, 101);
            this.comboBoxBan.Size = new System.Drawing.Size(180, 28);

            // groupBoxMonAn
            this.groupBoxMonAn.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Bold);
            this.groupBoxMonAn.Location = new System.Drawing.Point(35, 145);
            this.groupBoxMonAn.Size = new System.Drawing.Size(530, 260);
            this.groupBoxMonAn.Text = "Danh sách món ăn";

            // Thêm 16 nút món ăn vào groupBox
            string[] tenMon = {
                "Phở Bò", "Cơm Tấm", "Bún Chả", "Hủ Tiếu",
                "Mì Quảng", "Bánh Canh", "Cơm Chiên", "Bún Bò",
                "Bánh Mì", "Cháo Gà", "Gỏi Cuốn", "Bún Riêu",
                "Trà Đá", "Cà Phê", "Sinh Tố", "Nước Cam"
            };

            System.Windows.Forms.Button[] btnMons = {
                btnMon1, btnMon2, btnMon3, btnMon4,
                btnMon5, btnMon6, btnMon7, btnMon8,
                btnMon9, btnMon10, btnMon11, btnMon12,
                btnMon13, btnMon14, btnMon15, btnMon16
            };

            int w = 120, h = 45;
            int startX = 15, startY = 35, spacingX = 130, spacingY = 55;

            for (int i = 0; i < btnMons.Length; i++)
            {
                btnMons[i].Text = tenMon[i];
                btnMons[i].Size = new System.Drawing.Size(w, h);
                btnMons[i].Location = new System.Drawing.Point(startX + (i % 4) * spacingX, startY + (i / 4) * spacingY);
                this.groupBoxMonAn.Controls.Add(btnMons[i]);
            }

            // listViewOrder
            this.listViewOrder.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
                this.colTenMon,
                this.colSoLuong
            });
            this.listViewOrder.Font = new System.Drawing.Font("Segoe UI", 11F);
            this.listViewOrder.FullRowSelect = true;
            this.listViewOrder.GridLines = true;
            this.listViewOrder.Location = new System.Drawing.Point(35, 420);
            this.listViewOrder.Size = new System.Drawing.Size(530, 180);
            this.listViewOrder.View = System.Windows.Forms.View.Details;

            // colTenMon
            this.colTenMon.Text = "Tên món ăn";
            this.colTenMon.Width = 360;

            // colSoLuong
            this.colSoLuong.Text = "Số lượng";
            this.colSoLuong.Width = 130;

            // btnXoa
            this.btnXoa.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Bold);
            this.btnXoa.Location = new System.Drawing.Point(200, 620);
            this.btnXoa.Size = new System.Drawing.Size(160, 45);
            this.btnXoa.Text = "Xóa danh sách";

            // btnOrder
            this.btnOrder.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Bold);
            this.btnOrder.Location = new System.Drawing.Point(390, 620);
            this.btnOrder.Size = new System.Drawing.Size(175, 45);
            this.btnOrder.Text = "Order";

            // Form1
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.WhiteSmoke;
            this.ClientSize = new System.Drawing.Size(600, 690);
            this.Controls.Add(this.btnOrder);
            this.Controls.Add(this.btnXoa);
            this.Controls.Add(this.listViewOrder);
            this.Controls.Add(this.groupBoxMonAn);
            this.Controls.Add(this.comboBoxBan);
            this.Controls.Add(this.labelChonBan);
            this.Controls.Add(this.panelHeader);
            this.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.Name = "Form1";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Ứng dụng Order - Quán Ăn Nhanh";

            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxLogo)).EndInit();
            this.panelHeader.ResumeLayout(false);
            this.groupBoxMonAn.ResumeLayout(false);
            this.ResumeLayout(false);
            this.PerformLayout();
        }

        #endregion

        private System.Windows.Forms.PictureBox pictureBoxLogo;
        private System.Windows.Forms.Panel panelHeader;
        private System.Windows.Forms.Label labelTitle;
        private System.Windows.Forms.Label labelChonBan;
        private System.Windows.Forms.ComboBox comboBoxBan;
        private System.Windows.Forms.GroupBox groupBoxMonAn;

        private System.Windows.Forms.Button btnMon1;
        private System.Windows.Forms.Button btnMon2;
        private System.Windows.Forms.Button btnMon3;
        private System.Windows.Forms.Button btnMon4;
        private System.Windows.Forms.Button btnMon5;
        private System.Windows.Forms.Button btnMon6;
        private System.Windows.Forms.Button btnMon7;
        private System.Windows.Forms.Button btnMon8;
        private System.Windows.Forms.Button btnMon9;
        private System.Windows.Forms.Button btnMon10;
        private System.Windows.Forms.Button btnMon11;
        private System.Windows.Forms.Button btnMon12;
        private System.Windows.Forms.Button btnMon13;
        private System.Windows.Forms.Button btnMon14;
        private System.Windows.Forms.Button btnMon15;
        private System.Windows.Forms.Button btnMon16;

        private System.Windows.Forms.ListView listViewOrder;
        private System.Windows.Forms.ColumnHeader colTenMon;
        private System.Windows.Forms.ColumnHeader colSoLuong;
        private System.Windows.Forms.Button btnXoa;
        private System.Windows.Forms.Button btnOrder;
    }
}
