﻿    using System;
    using System.Collections.Generic;
    using System.IO;
    using System.Windows.Forms;

    namespace lab3
    {
        public partial class Form1 : Form
        {
            private Dictionary<string, int> orderList = new Dictionary<string, int>();

            public Form1()
            {
                InitializeComponent();
                LoadTableList();
                AddFoodButtonEvents();
                AddButtonEvents(); // Gắn sự kiện cho nút Order và Xóa
            }

            private void LoadTableList()
            {
                comboBoxBan.Items.AddRange(new string[] { "Bàn 1", "Bàn 2", "Bàn 3", "Bàn 4", "Bàn 5" });
                comboBoxBan.SelectedIndex = 0;
            }

            private void AddFoodButtonEvents()
            {
                foreach (Control c in groupBoxMonAn.Controls)
                {
                    if (c is Button)
                        c.Click += BtnFood_Click;
                }
            }

            private void AddButtonEvents()
            {
                btnOrder.Click += btnOrder_Click;
                btnXoa.Click += btnXoa_Click;
            }

            private void BtnFood_Click(object sender, EventArgs e)
            {
                Button btn = sender as Button;
                string tenMon = btn.Text;

                if (orderList.ContainsKey(tenMon))
                    orderList[tenMon]++;
                else
                    orderList[tenMon] = 1;

                HienThiLenListView();
            }

            private void HienThiLenListView()
            {
                listViewOrder.Items.Clear();
                foreach (var item in orderList)
                {
                    ListViewItem lvi = new ListViewItem(item.Key);
                    lvi.SubItems.Add(item.Value.ToString());
                    listViewOrder.Items.Add(lvi);
                }
            }

            private void btnXoa_Click(object sender, EventArgs e)
            {
                orderList.Clear();
                listViewOrder.Items.Clear();
            }

            private void btnOrder_Click(object sender, EventArgs e)
            {
                if (orderList.Count == 0)
                {
                    MessageBox.Show("Chưa có món nào được chọn!", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    return;
                }

                string tenBan = comboBoxBan.SelectedItem.ToString();
                string folderPath = Path.Combine(Application.StartupPath, "Orders");

                if (!Directory.Exists(folderPath))
                    Directory.CreateDirectory(folderPath);

                string fileName = $"Order_{tenBan.Replace(" ", "_")}_{DateTime.Now:yyyyMMdd_HHmmss}.txt";
                string fullPath = Path.Combine(folderPath, fileName);

                using (StreamWriter writer = new StreamWriter(fullPath))
                {
                    writer.WriteLine($"BÀN: {tenBan}");
                    writer.WriteLine($"THỜI GIAN: {DateTime.Now}");
                    writer.WriteLine("======================");
                    foreach (var item in orderList)
                    {
                        writer.WriteLine($"{item.Key} - Số lượng: {item.Value}");
                    }
                    writer.WriteLine("======================");
                    writer.WriteLine("ĐÃ GỬI NHÀ BẾP");
                }

                MessageBox.Show($"Đã lưu order vào file:\n{fullPath}", "Thành công", MessageBoxButtons.OK, MessageBoxIcon.Information);

                orderList.Clear();
                listViewOrder.Items.Clear();
            }
        }
    }
