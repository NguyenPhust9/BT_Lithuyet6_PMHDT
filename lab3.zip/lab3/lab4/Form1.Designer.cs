﻿namespace lab4
{
    partial class Form1
    {
        private System.ComponentModel.IContainer components = null;

        private System.Windows.Forms.Button btnMoKetNoi;
        private System.Windows.Forms.Button btnXemThongTin;
        private System.Windows.Forms.Button btnLoadDanhSach;
        private System.Windows.Forms.TextBox txtMaSV;
        private System.Windows.Forms.TextBox txtHoTen;
        private System.Windows.Forms.TextBox txtGioiTinh;
        private System.Windows.Forms.TextBox txtNgaySinh;
        private System.Windows.Forms.TextBox txtQueQuan;
        private System.Windows.Forms.TextBox txtMaLop;
        private System.Windows.Forms.ListView lsvSinhVien;

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label7;

        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        private void InitializeComponent()
        {
            this.btnMoKetNoi = new System.Windows.Forms.Button();
            this.btnXemThongTin = new System.Windows.Forms.Button();
            this.btnLoadDanhSach = new System.Windows.Forms.Button();
            this.txtMaSV = new System.Windows.Forms.TextBox();
            this.txtHoTen = new System.Windows.Forms.TextBox();
            this.txtGioiTinh = new System.Windows.Forms.TextBox();
            this.txtNgaySinh = new System.Windows.Forms.TextBox();
            this.txtQueQuan = new System.Windows.Forms.TextBox();
            this.txtMaLop = new System.Windows.Forms.TextBox();
            this.lsvSinhVien = new System.Windows.Forms.ListView();

            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();

            this.SuspendLayout();

            // btnMoKetNoi
            this.btnMoKetNoi.Location = new System.Drawing.Point(12, 12);
            this.btnMoKetNoi.Name = "btnMoKetNoi";
            this.btnMoKetNoi.Size = new System.Drawing.Size(100, 30);
            this.btnMoKetNoi.TabIndex = 0;
            this.btnMoKetNoi.Text = "Mở Kết Nối";
            this.btnMoKetNoi.UseVisualStyleBackColor = true;
            this.btnMoKetNoi.Click += new System.EventHandler(this.btnMoKetNoi_Click);

            // label1 - Mã Sinh Viên
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(12, 60);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(75, 17);
            this.label1.Text = "Mã Sinh Viên:";

            // txtMaSV
            this.txtMaSV.Location = new System.Drawing.Point(110, 57);
            this.txtMaSV.Name = "txtMaSV";
            this.txtMaSV.Size = new System.Drawing.Size(150, 22);

            // btnXemThongTin
            this.btnXemThongTin.Location = new System.Drawing.Point(270, 55);
            this.btnXemThongTin.Name = "btnXemThongTin";
            this.btnXemThongTin.Size = new System.Drawing.Size(110, 25);
            this.btnXemThongTin.TabIndex = 3;
            this.btnXemThongTin.Text = "Xem Thông Tin";
            this.btnXemThongTin.UseVisualStyleBackColor = true;
            this.btnXemThongTin.Click += new System.EventHandler(this.btnXemThongTin_Click);

            // label2 - Họ Tên
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(12, 95);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(52, 17);
            this.label2.Text = "Họ Tên:";

            // txtHoTen
            this.txtHoTen.Location = new System.Drawing.Point(110, 92);
            this.txtHoTen.Name = "txtHoTen";
            this.txtHoTen.ReadOnly = true;
            this.txtHoTen.Size = new System.Drawing.Size(270, 22);

            // label3 - Giới Tính
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(12, 130);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(65, 17);
            this.label3.Text = "Giới Tính:";

            // txtGioiTinh
            this.txtGioiTinh.Location = new System.Drawing.Point(110, 127);
            this.txtGioiTinh.Name = "txtGioiTinh";
            this.txtGioiTinh.ReadOnly = true;
            this.txtGioiTinh.Size = new System.Drawing.Size(100, 22);

            // label4 - Ngày Sinh
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(12, 165);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(71, 17);
            this.label4.Text = "Ngày Sinh:";

            // txtNgaySinh
            this.txtNgaySinh.Location = new System.Drawing.Point(110, 162);
            this.txtNgaySinh.Name = "txtNgaySinh";
            this.txtNgaySinh.ReadOnly = true;
            this.txtNgaySinh.Size = new System.Drawing.Size(120, 22);

            // label5 - Quê Quán
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(12, 200);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(63, 17);
            this.label5.Text = "Quê Quán:";

            // txtQueQuan
            this.txtQueQuan.Location = new System.Drawing.Point(110, 197);
            this.txtQueQuan.Name = "txtQueQuan";
            this.txtQueQuan.ReadOnly = true;
            this.txtQueQuan.Size = new System.Drawing.Size(270, 22);

            // label6 - Mã Lớp
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(12, 235);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(52, 17);
            this.label6.Text = "Mã Lớp:";

            // txtMaLop
            this.txtMaLop.Location = new System.Drawing.Point(110, 232);
            this.txtMaLop.Name = "txtMaLop";
            this.txtMaLop.ReadOnly = true;
            this.txtMaLop.Size = new System.Drawing.Size(150, 22);

            // btnLoadDanhSach
            this.btnLoadDanhSach.Location = new System.Drawing.Point(12, 270);
            this.btnLoadDanhSach.Name = "btnLoadDanhSach";
            this.btnLoadDanhSach.Size = new System.Drawing.Size(140, 30);
            this.btnLoadDanhSach.TabIndex = 15;
            this.btnLoadDanhSach.Text = "Load Danh Sách";
            this.btnLoadDanhSach.UseVisualStyleBackColor = true;
            this.btnLoadDanhSach.Click += new System.EventHandler(this.btnLoadDanhSach_Click);

            // lsvSinhVien
            this.lsvSinhVien.Location = new System.Drawing.Point(12, 310);
            this.lsvSinhVien.Name = "lsvSinhVien";
            this.lsvSinhVien.Size = new System.Drawing.Size(600, 200);
            this.lsvSinhVien.TabIndex = 16;
            this.lsvSinhVien.View = System.Windows.Forms.View.Details;
            this.lsvSinhVien.FullRowSelect = true;
            this.lsvSinhVien.GridLines = true;

            // Thêm cột cho ListView
            this.lsvSinhVien.Columns.Add("Mã SV", 80);
            this.lsvSinhVien.Columns.Add("Họ Tên", 150);
            this.lsvSinhVien.Columns.Add("Giới Tính", 70);
            this.lsvSinhVien.Columns.Add("Ngày Sinh", 90);
            this.lsvSinhVien.Columns.Add("Quê Quán", 130);
            this.lsvSinhVien.Columns.Add("Mã Lớp", 80);

            // label7 - Tiêu đề form
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Bold);
            this.label7.Location = new System.Drawing.Point(12, 530);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(180, 29);
            this.label7.Text = "Tra cứu Sinh Viên";

            // Form1
            this.ClientSize = new System.Drawing.Size(630, 570);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.lsvSinhVien);
            this.Controls.Add(this.btnLoadDanhSach);
            this.Controls.Add(this.txtMaLop);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.txtQueQuan);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.txtNgaySinh);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.txtGioiTinh);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.txtHoTen);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.btnXemThongTin);
            this.Controls.Add(this.txtMaSV);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.btnMoKetNoi);

            this.Name = "Form1";
            this.Text = "Tra cứu Sinh Viên";
            this.ResumeLayout(false);
            this.PerformLayout();
        }
    }
}
