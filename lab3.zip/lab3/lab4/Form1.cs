﻿using Npgsql;
using System;
using System.Data;
using System.Windows.Forms;

namespace lab4
{
    public partial class Form1 : Form
    {
        string connStr = "Host=localhost;Port=5432;Username=postgres;Password=123456;Database=qlsinhvien";
        NpgsqlConnection conn;

        public Form1()
        {
            InitializeComponent();
        }

        // Mở kết nối
        private void btnMoKetNoi_Click(object sender, EventArgs e)
        {
            try
            {
                if (conn == null)
                    conn = new NpgsqlConnection(connStr);

                if (conn.State == ConnectionState.Closed)
                {
                    conn.Open();
                    MessageBox.Show("Kết nối thành công!");
                }
                else
                {
                    MessageBox.Show("Kết nối đã mở.");
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Lỗi: " + ex.Message);
            }
        }

        // Tìm sinh viên theo mã và hiển thị chi tiết
        private void btnXemThongTin_Click(object sender, EventArgs e)
        {
            if (conn == null || conn.State == ConnectionState.Closed)
            {
                MessageBox.Show("Bạn chưa mở kết nối!");
                return;
            }

            string maSV = txtMaSV.Text.Trim();
            if (string.IsNullOrEmpty(maSV))
            {
                MessageBox.Show("Vui lòng nhập mã sinh viên.");
                return;
            }

            try
            {
                string sql = "SELECT tensv, gioitinh, ngaysinh, quequan, malop FROM sinhvien WHERE masv = @masv";
                using (var cmd = new NpgsqlCommand(sql, conn))
                {
                    cmd.Parameters.AddWithValue("masv", maSV);

                    using (var reader = cmd.ExecuteReader())
                    {
                        if (reader.Read())
                        {
                            txtHoTen.Text = reader.GetString(0);
                            txtGioiTinh.Text = reader.GetString(1);
                            txtNgaySinh.Text = reader.GetDateTime(2).ToString("dd/MM/yyyy");
                            txtQueQuan.Text = reader.GetString(3);
                            txtMaLop.Text = reader.GetString(4);
                        }
                        else
                        {
                            MessageBox.Show("Không tìm thấy sinh viên có mã này.");
                            ClearTextBoxes();
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Lỗi truy vấn: " + ex.Message);
            }
        }

        // Load tất cả sinh viên và hiển thị lên ListView
        private void btnLoadDanhSach_Click(object sender, EventArgs e)
        {
            if (conn == null || conn.State == ConnectionState.Closed)
            {
                MessageBox.Show("Bạn chưa mở kết nối!");
                return;
            }

            try
            {
                string sql = "SELECT masv, tensv, gioitinh, ngaysinh, quequan, malop FROM sinhvien ORDER BY masv";
                using (var cmd = new NpgsqlCommand(sql, conn))
                using (var reader = cmd.ExecuteReader())
                {
                    lsvSinhVien.Items.Clear();

                    while (reader.Read())
                    {
                        var item = new ListViewItem(reader.GetString(0)); // masv
                        item.SubItems.Add(reader.GetString(1)); // tensv
                        item.SubItems.Add(reader.GetString(2)); // gioitinh
                        item.SubItems.Add(reader.GetDateTime(3).ToString("dd/MM/yyyy")); // ngaysinh
                        item.SubItems.Add(reader.GetString(4)); // quequan
                        item.SubItems.Add(reader.GetString(5)); // malop

                        lsvSinhVien.Items.Add(item);
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Lỗi truy vấn: " + ex.Message);
            }
        }

        // Xóa dữ liệu trong các TextBox hiển thị thông tin sinh viên
        private void ClearTextBoxes()
        {
            txtHoTen.Text = "";
            txtGioiTinh.Text = "";
            txtNgaySinh.Text = "";
            txtQueQuan.Text = "";
            txtMaLop.Text = "";
        }
    }
}
